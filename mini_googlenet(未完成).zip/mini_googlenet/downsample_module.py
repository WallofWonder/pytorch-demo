import torch
from torch import nn

from mini_googlenet.conv_module import ConvModule


class DownSampleModule(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(DownSampleModule, self).__init__()
        self.conv_module = ConvModule(in_channels=in_channels,
                                      out_channels=out_channels,
                                      kernel_size=3,
                                      stride=2)
        self.max_pooling = nn.MaxPool2d(kernel_size=3, stride=2)

    def forward(self, x):
        # print("DownSampleModule: {}".format(x.shape))
        conv = self.conv_module(x)
        max_pool = self.max_pooling(x)
        x = torch.cat([conv, max_pool], dim=1)
        return x
