import torch
from torch import nn
from torch.nn import Sequential
import torch.nn.functional as F
from mini_googlenet.conv_module import ConvModule
from mini_googlenet.downsample_module import DownSampleModule
from mini_googlenet.inception_module import InceptionModule


class MiniGoogleNet(nn.Module):
    def __init__(self):
        super(MiniGoogleNet, self).__init__()
        # todo 放弃 lazy，指定输入通道
        self.features = Sequential(
            ConvModule(in_channels=1, out_channels=96, kernel_size=3, stride=1),
            InceptionModule(in_channels=96, out_chan_1x1=32, out_chan_3x3=32),
            InceptionModule(in_channels=64, out_chan_1x1=32, out_chan_3x3=48),
            DownSampleModule(in_channels=80, out_channels=80),
            InceptionModule(in_channels=160, out_chan_1x1=112, out_chan_3x3=48),
            InceptionModule(in_channels=160, out_chan_1x1=96, out_chan_3x3=64),
            InceptionModule(in_channels=160, out_chan_1x1=80, out_chan_3x3=80),
            InceptionModule(in_channels=160, out_chan_1x1=48, out_chan_3x3=96),
            DownSampleModule(in_channels=144, out_channels=96),
            InceptionModule(in_channels=240, out_chan_1x1=176, out_chan_3x3=160),
            InceptionModule(in_channels=336, out_chan_1x1=176, out_chan_3x3=160),
            nn.AvgPool2d(kernel_size=6),
            nn.Dropout(p=0.5),
        )

        self.classifier = nn.Sequential(
            nn.LazyLinear(out_features=10),
            nn.Softmax()
        )

        # self.conv_96 = ConvModule(out_channels=96, kernel_size=3, stride=1)
        # self.inception_32_32 = InceptionModule(out_chan_1x1=32, out_chan_3x3=32)
        # self.inception_32_48 = InceptionModule(out_chan_1x1=32, out_chan_3x3=48)
        # self.down_sample_80 = DownSampleModule(out_channels=80)
        # self.inception_112_48 = InceptionModule(out_chan_1x1=112, out_chan_3x3=48)
        # self.inception_96_64 = InceptionModule(out_chan_1x1=96, out_chan_3x3=64)
        # self.inception_80_80 = InceptionModule(out_chan_1x1=80, out_chan_3x3=80)
        # self.inception_48_96 = InceptionModule(out_chan_1x1=48, out_chan_3x3=96)
        # self.down_sample_96 = DownSampleModule(out_channels=96)
        # self.inception_176_160 = InceptionModule(out_chan_1x1=176, out_chan_3x3=160)
        # self.fc = nn.LazyLinear(out_features=10)

    def forward(self, x):
        x = self.features(x)
        x = x.view(x.size(0), -1)
        x = self.classifier(x)

        # x = self.conv_96(x)
        # x = self.inception_32_32(x)
        # x = self.inception_32_48(x)
        # x = self.down_sample_80(x)
        # x = self.inception_112_48(x)
        # x = self.inception_96_64(x)
        # x = self.inception_80_80(x)
        # x = self.inception_48_96(x)
        # x = self.down_sample_96(x)
        # x = self.inception_176_160(x)
        # x = F.avg_pool2d(x)
        # x = torch.flatten(x)
        # x = F.softmax(x)

        return x
