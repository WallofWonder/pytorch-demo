import torch
import torch.nn.functional as F
from torch.optim.lr_scheduler import ReduceLROnPlateau, LambdaLR
from torch.utils.tensorboard import SummaryWriter

from mini_googlenet.data_loader import load_data
from mini_googlenet.net import MiniGoogleNet

n_epochs = 70
init_lr = 5e-3
batch_size_train = 64
batch_size_test = 64
momentum = 0.9

net = None
train_loader, test_loader = None, None
optimizer = None
scheduler = None

log_interval = 10


def poly_decay(i):
    # initialize the maximum number of epochs, base learning rate,
    # and power of the polynomial
    power = 1.0
    # compute the new learning rate based on polynomial decay
    lda = (1 - (i / float(n_epochs))) ** power

    return lda


def train():
    net.train()
    for batch_idx, (data, target) in enumerate(train_loader):
        data, target = data.to(device), target.to(device)
        # 每个batch重新计算梯度
        optimizer.zero_grad()
        # 前向计算出预测输出
        output = net(data)
        # todo 自己实现代价 categorical_crossentropy？
        loss = F.cross_entropy(output, target)
        # 求梯度
        loss.backward()
        # 更新参数
        optimizer.step()
        # 更新学习率
        scheduler.step()

        if batch_idx % log_interval == 0:
            print('{:.0f}%\tLoss: {:.6f}'.format(100. * batch_idx / len(train_loader), loss.item()))


def test():
    net.eval()
    test_loss = 0
    correct = 0
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            output = net(data)
            test_loss += F.cross_entropy(output, target, reduction='sum').item()
            predict = output.argmax(dim=1, keepdim=True)
            correct += predict.eq(target.view_as(predict)).sum().item()

    # 上面test_loss得到的是累加和，这里求得均值
    test_loss /= len(test_loader.dataset)
    print('\nTest set: Average loss: {:.4f}, Accuracy: {}/{} ({:.2f}%)'.format(
        test_loss, correct, len(test_loader.dataset),
        100. * correct / len(test_loader.dataset)))


if __name__ == '__main__':
    # 启用英伟达cuDNN加速框架和CUDA
    torch.backends.cudnn.enabled = True
    torch.manual_seed(seed=1)
    cuda_available = torch.cuda.is_available()
    device_name = torch.cuda.get_device_name(0) if cuda_available else "CPU"
    device = torch.device("cuda" if cuda_available else "cpu")
    print("Device: {}".format(device_name))

    writer = SummaryWriter(log_dir="./log", comment="MiniGoogleNet")

    net = MiniGoogleNet().to(device)
    train_loader, test_loader = load_data(batch_size_train=batch_size_train,
                                          batch_size_test=batch_size_test,
                                          use_cuda=cuda_available)
    # optimizer = torch.optim.SGD(net.parameters(), lr=init_lr, momentum=momentum)
    optimizer = torch.optim.Adam(net.parameters(), lr=init_lr)
    # todo 改成自己实现 poly scheduler？
    scheduler = LambdaLR(optimizer=optimizer, lr_lambda=poly_decay)

    for epoch in range(1, n_epochs + 1):
        print("training epoch :{} =================".format(epoch))
        train()
        test()
