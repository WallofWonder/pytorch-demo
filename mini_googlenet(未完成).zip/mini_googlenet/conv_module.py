from torch import nn
import torch.nn.functional as F


class ConvModule(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int, stride: int):
        super(ConvModule, self).__init__()
        self.conv = nn.LazyConv2d(out_channels=out_channels,
                                  kernel_size=kernel_size,
                                  stride=stride)
        self.bn = nn.BatchNorm2d(num_features=out_channels)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = F.relu(x)

        return x
