import torch
from torch import nn

from mini_googlenet.conv_module import ConvModule
from mini_googlenet.utils import pt_same_padding


class InceptionModule(nn.Module):
    def __init__(self, in_channels, out_chan_1x1, out_chan_3x3):
        super(InceptionModule, self).__init__()
        self.conv_module_1x1 = ConvModule(in_channels=in_channels,
                                          out_channels=out_chan_1x1,
                                          kernel_size=1,
                                          stride=1)
        self.conv_module_3x3 = ConvModule(in_channels=in_channels,
                                          out_channels=out_chan_3x3,
                                          kernel_size=3,
                                          stride=1)

    def forward(self, x):
        # print("InceptionModule: {}".format(x.shape))
        conv_1x1 = self.conv_module_1x1(pt_same_padding(x, kernel_size=1, stride=1))
        conv_3x3 = self.conv_module_3x3(pt_same_padding(x, kernel_size=3, stride=1))
        x = torch.cat([conv_1x1, conv_3x3], dim=1)
        return x
