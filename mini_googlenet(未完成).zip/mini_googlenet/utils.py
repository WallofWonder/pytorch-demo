import numpy as np
import torch
from torch import nn
import torch.nn.functional as F


def pt_same_padding(x: torch.Tensor, kernel_size: int, stride: int = 1):
    """
    仿照 tf 和 keras 实现 same padding  \n
    https://www.tensorflow.org/api_docs/python/tf/nn#notes_on_padding_2 \n
    https://discuss.pytorch.org/t/same-padding-equivalent-in-pytorch
    """
    left, right, top, bot = 0, 0, 0, 0
    # 计算四边的padding数
    in_height, in_width = x.shape[2], x.shape[3]

    # out_height = np.ceil(float(in_height) / float(stride))
    # out_width = np.ceil(float(in_width) / float(stride))

    if in_height % stride == 0:
        pad_along_height = max(kernel_size - stride, 0)
    else:
        pad_along_height = max(kernel_size - (in_height % stride), 0)
    if in_width % stride == 0:
        pad_along_width = max(kernel_size - stride, 0)
    else:
        pad_along_width = max(kernel_size - (in_width % stride), 0)

    top = pad_along_height // 2
    bot = pad_along_height - top
    left = pad_along_width // 2
    right = pad_along_width - left

    x = F.pad(x, (left, right, top, bot))
    return x


def pt_categorical_crossentropy(pred, label):
    """
    使用pytorch 来实现 categorical_crossentropy
    """
    # print(-label * torch.log(pred))
    return torch.sum(-label * torch.log(pred))
