import torch.utils.data
from torchvision import datasets, transforms
from torchvision.transforms import InterpolationMode


def load_data(batch_size_train, batch_size_test, use_cuda=False):
    # GPU训练需要的参数
    kwargs = {'num_workers': 4, 'pin_memory': True} if use_cuda else {}
    transform = transforms.Compose([
        # 仿射变换
        transforms.RandomAffine(degrees=0, translate=(0.1, 0.1), interpolation=InterpolationMode.NEAREST),
        # 全部图像水平翻转
        transforms.RandomHorizontalFlip(),
        # 把[0,255]的(H,W,C)的图片转换为[0,1]的(C,H,W)的图片
        transforms.ToTensor(),
        # 标准化 均值和标准差的值参考：https://blog.csdn.net/weixin_43821559/article/details/123459085
        transforms.Normalize(mean=(0.4914, 0.4821, 0.4465), std=(0.2470, 0.2435, 0.2616))
    ])

    train_data = torch.utils.data.DataLoader(
        datasets.CIFAR10(
            root="../data",
            train=True,
            download=True,
            transform=transform),
        batch_size=batch_size_train,
        shuffle=True,
        **kwargs)

    test_data = torch.utils.data.DataLoader(
        datasets.CIFAR10(
            root="../data",
            train=False,
            transform=transform),
        batch_size=batch_size_test,
        shuffle=True,
        **kwargs)

    return train_data, test_data
